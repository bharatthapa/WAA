package com.students.exception;

public class NotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9060751397339719682L;
	private String itemId;
	private String message = "Item Not Found for this ID ";

	public NotFoundException() {
	}

	public NotFoundException(String productId, String message) {
		this.itemId = productId;

		if (message != null)
			this.message = message;

	}

	public String getFullMessage() {
		return (message + itemId);
	}

	public String getProductId() {
		return itemId;
	}

	@Override
	public String getLocalizedMessage() {
		// TODO Auto-generated method stub
		return super.getLocalizedMessage();
	}

}