package com.students.contoller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.students.domain.Student;
import com.students.domain.Student.Gender;
import com.students.exception.NotFoundException;

@Controller
@RequestMapping(value = "/registration")
public class StudentController {

	MultipartFile image;

	@RequestMapping(method = RequestMethod.GET)
	public String showForm(Model model) {
		model.addAttribute("student", new Student());
		model.addAttribute("gender", Gender.values());
		return "registration";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String processForm(@Valid @ModelAttribute Student student,
			BindingResult bindingResult, HttpServletRequest request,
			HttpServletResponse response) {

		String rootDirectory = request.getSession().getServletContext()
				.getRealPath("/");
		System.out.println("root directory: " + rootDirectory);
		if (student.getFile() != null && !student.getFile().isEmpty()) {
			try {
				student.getFile().transferTo(
						new File(rootDirectory + "/resources/images/"
								+ student.getEmail() + ".jpeg"));
			} catch (Exception e) {
				throw new RuntimeException("Product Image saving failed", e);
			}
		}
		if (bindingResult.hasErrors()) {
			return "registration";
		}
		return "success";

	}

	@ExceptionHandler(NotFoundException.class)
	public ModelAndView handleError(HttpServletRequest req,
			NotFoundException exception) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("invalidProductId", exception.getFullMessage());
		mav.setViewName("productNotFound");
		return mav;
	}

}
