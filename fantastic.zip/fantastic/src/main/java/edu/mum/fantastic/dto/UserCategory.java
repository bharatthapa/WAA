package edu.mum.fantastic.dto;

import edu.mum.fantastic.domain.enumeration.Category;

/**
 * Created by bipin on 10/11/15.
 */
public class UserCategory {

    Category category;

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
