
package edu.mum.fantastic.service;
import edu.mum.fantastic.domain.Dating;
/**
 *
 * @author sudarshan
 */

public interface DatingService extends AbstractService<Dating>
{
    
}
