package edu.mum.fantastic.domain.enumeration;

/**
 * Created by bipin on 10/10/15.
 */
public enum Category {

    TRAVEL, DATING, HANGOUT
}
