package mum.edu.validator;

import java.util.List;


public interface CalculateValidator {

	public List<String> validate(Object  object ) ;
}
