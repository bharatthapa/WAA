package com.students.domain;

public class Contact {
	private String firstname;
	private String lastname;
	private String email;
	private String telephone;
	// getters and setters
}