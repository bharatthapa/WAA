package np.com.carpool.service;

import np.com.carpool.domain.User;

public interface UserService extends AbstractService<User, Long> {
}
