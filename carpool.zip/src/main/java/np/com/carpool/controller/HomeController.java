package np.com.carpool.controller;

import np.com.carpool.domain.User;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {

    @RequestMapping(value = {"/", "/login"}, method = RequestMethod.GET)
    public String login(@ModelAttribute("user") User user) {
        return "index";
    }
    
    @RequestMapping(value={"/home/secure"}, method = RequestMethod.GET)
    public String home(){
        System.out.println("this is home");
    	return "home";
    }

}
